# hw3

I have organized the job scripts(*.cmd*) and inside the `hb` and `grape` folders. The outputs and the errors are in the folders. 

For grape interactive jobs, I took screenshots (*.png*). 
